from __future__ import annotations

from collections import defaultdict
from decimal import Decimal
from typing import Iterable

from sqlalchemy.orm import Session

from app.models.bank_reconciliation import (
    BankAccount,
    BankReconciliation,
    BankTransaction,
)
from app.models.financial_record import (
    FinancialRecord,
    FinancialRecordPayment,
)


BANK_PAYMENT_MARKERS = (
    "bank",
    "transfer",
    "wire",
    "sepa",
    "swift",
    "iban",
    "card",
    "direct debit",
)

NON_BANK_PAYMENT_METHODS = {
    "cash",
    "cash payment",
    "cash receipt",
    "petty cash",
    "check",
    "cheque",
}


def money(value) -> Decimal:
    return Decimal(str(value or 0))


def classify_payment_method(value: str | None) -> str:
    method = " ".join(str(value or "").strip().lower().split())

    if not method:
        return "unclassified"

    if method in NON_BANK_PAYMENT_METHODS:
        return "non_bank"

    if any(marker in method for marker in BANK_PAYMENT_MARKERS):
        return "bank"

    return "unclassified"


def aggregate_signed_amounts(rows: Iterable[tuple[str, object]]) -> dict:
    inflow = defaultdict(Decimal)
    outflow = defaultdict(Decimal)

    for currency, raw_amount in rows:
        amount = money(raw_amount)
        currency = str(currency or "").upper()

        if not currency:
            continue

        if amount > 0:
            inflow[currency] += amount
        elif amount < 0:
            outflow[currency] += abs(amount)

    currencies = sorted(set(inflow) | set(outflow))

    return {
        "inflow": {c: str(inflow[c]) for c in currencies},
        "outflow": {c: str(outflow[c]) for c in currencies},
        "net": {
            c: str(inflow[c] - outflow[c])
            for c in currencies
        },
    }


def calculate_closing_balance(opening, net):
    return money(opening) + money(net)


def cash_flow_report(
    db: Session,
    owner_id: int,
    is_superuser: bool,
    start_date,
    end_date,
    currency: str | None = None,
    account_id: int | None = None,
) -> dict:
    currency_filter = str(currency or "").strip().upper() or None

    account_query = db.query(BankAccount)

    if not is_superuser:
        account_query = account_query.filter(
            BankAccount.owner_id == owner_id
        )

    if account_id is not None:
        account_query = account_query.filter(
            BankAccount.id == account_id
        )

    if currency_filter:
        account_query = account_query.filter(
            BankAccount.currency == currency_filter
        )

    accounts = account_query.order_by(BankAccount.id).all()
    account_ids = [account.id for account in accounts]

    account_metrics = {}

    for account in accounts:
        account_metrics[account.id] = {
            "id": account.id,
            "name": account.name,
            "bank_name": account.bank_name,
            "iban": account.iban,
            "currency": str(account.currency or "").upper(),
            "opening_balance": money(account.opening_balance),
            "period_inflow": Decimal("0"),
            "period_outflow": Decimal("0"),
            "period_net": Decimal("0"),
            "closing_balance": money(account.opening_balance),
            "reconciliation_status": None,
            "reconciliation_difference": None,
        }

    bank_transactions = []

    if account_ids:
        tx_query = db.query(BankTransaction).filter(
            BankTransaction.account_id.in_(account_ids),
            BankTransaction.status != "ignored",
        )

        if not is_superuser:
            tx_query = tx_query.filter(
                BankTransaction.owner_id == owner_id
            )

        tx_query = tx_query.filter(
            BankTransaction.transaction_date <= end_date
        )

        if currency_filter:
            tx_query = tx_query.filter(
                BankTransaction.currency == currency_filter
            )

        bank_transactions = tx_query.all()

    bank_period_rows = []
    bank_opening_rows = []

    transaction_count = 0
    ignored_transaction_count = 0

    for tx in bank_transactions:
        tx_currency = str(tx.currency or "").upper()
        amount = money(tx.amount)

        if tx.status == "ignored":
            ignored_transaction_count += 1
            continue

        if tx.transaction_date < start_date:
            bank_opening_rows.append((tx_currency, amount))

            if tx.account_id in account_metrics:
                account_metrics[tx.account_id]["opening_balance"] += amount

            continue

        if start_date <= tx.transaction_date <= end_date:
            bank_period_rows.append((tx_currency, amount))
            transaction_count += 1

            if tx.account_id in account_metrics:
                metrics = account_metrics[tx.account_id]

                if amount > 0:
                    metrics["period_inflow"] += amount
                elif amount < 0:
                    metrics["period_outflow"] += abs(amount)

                metrics["period_net"] += amount

    bank_totals = aggregate_signed_amounts(bank_period_rows)

    opening_by_currency = defaultdict(Decimal)

    for account in account_metrics.values():
        opening_by_currency[
            account["currency"]
        ] += account["opening_balance"]

    closing_by_currency = defaultdict(Decimal)

    for account in account_metrics.values():
        closing = calculate_closing_balance(
            account["opening_balance"],
            account["period_net"],
        )

        account["closing_balance"] = closing

        closing_by_currency[
            account["currency"]
        ] += closing

    reconciliation_map = {}

    if account_ids:
        reconciliation_query = db.query(BankReconciliation).filter(
            BankReconciliation.account_id.in_(account_ids)
        )

        if not is_superuser:
            reconciliation_query = reconciliation_query.filter(
                BankReconciliation.owner_id == owner_id
            )

        reconciliations = reconciliation_query.order_by(
            BankReconciliation.period_end.desc(),
            BankReconciliation.id.desc(),
        ).all()

        for reconciliation in reconciliations:
            if reconciliation.account_id not in reconciliation_map:
                reconciliation_map[reconciliation.account_id] = reconciliation

    for account_id_value, metrics in account_metrics.items():
        reconciliation = reconciliation_map.get(account_id_value)

        if reconciliation:
            metrics["reconciliation_status"] = reconciliation.status
            metrics["reconciliation_difference"] = str(
                money(reconciliation.difference)
            )

    recorded_payment_query = (
        db.query(FinancialRecordPayment, FinancialRecord)
        .join(
            FinancialRecord,
            FinancialRecord.id == FinancialRecordPayment.record_id,
        )
        .filter(
            FinancialRecordPayment.payment_date >= start_date,
            FinancialRecordPayment.payment_date <= end_date,
        )
    )

    if not is_superuser:
        recorded_payment_query = recorded_payment_query.filter(
            FinancialRecordPayment.owner_id == owner_id,
            FinancialRecord.owner_id == owner_id,
        )

    recorded_payments = recorded_payment_query.all()

    non_bank_rows = []
    unclassified_rows = []

    for payment, record in recorded_payments:
        classification = classify_payment_method(
            payment.payment_method
        )

        currency_value = str(record.currency or "").upper()
        amount = money(payment.amount)

        if classification == "non_bank":
            signed_amount = (
                amount
                if record.record_type == "income"
                else -amount
            )
            non_bank_rows.append(
                (currency_value, signed_amount)
            )

        elif classification == "unclassified":
            signed_amount = (
                amount
                if record.record_type == "income"
                else -amount
            )
            unclassified_rows.append(
                (currency_value, signed_amount)
            )

    non_bank_totals = aggregate_signed_amounts(non_bank_rows)
    unclassified_totals = aggregate_signed_amounts(
        unclassified_rows
    )

    total_inflow = defaultdict(Decimal)
    total_outflow = defaultdict(Decimal)

    for source in (bank_totals, non_bank_totals):
        for cur, value in source["inflow"].items():
            total_inflow[cur] += money(value)

        for cur, value in source["outflow"].items():
            total_outflow[cur] += money(value)

    currencies = sorted(
        set(total_inflow)
        | set(total_outflow)
        | set(opening_by_currency)
        | set(closing_by_currency)
    )

    total_net = {
        cur: total_inflow[cur] - total_outflow[cur]
        for cur in currencies
    }

    return {
        "period": {
            "start": start_date.isoformat(),
            "end": end_date.isoformat(),
        },
        "cash_flow": {
            "inflow_by_currency": {
                cur: str(total_inflow[cur])
                for cur in currencies
            },
            "outflow_by_currency": {
                cur: str(total_outflow[cur])
                for cur in currencies
            },
            "net_by_currency": {
                cur: str(total_net[cur])
                for cur in currencies
            },
        },
        "bank": {
            "opening_balance_by_currency": {
                cur: str(opening_by_currency[cur])
                for cur in currencies
            },
            "closing_balance_by_currency": {
                cur: str(closing_by_currency[cur])
                for cur in currencies
            },
            "inflow_by_currency": bank_totals["inflow"],
            "outflow_by_currency": bank_totals["outflow"],
            "net_by_currency": bank_totals["net"],
            "transaction_count": transaction_count,
            "ignored_transaction_count": ignored_transaction_count,
        },
        "non_bank_recorded": {
            "inflow_by_currency": non_bank_totals["inflow"],
            "outflow_by_currency": non_bank_totals["outflow"],
            "net_by_currency": non_bank_totals["net"],
        },
        "unclassified_recorded_payments": {
            "inflow_by_currency": unclassified_totals["inflow"],
            "outflow_by_currency": unclassified_totals["outflow"],
            "net_by_currency": unclassified_totals["net"],
        },
        "accounts": [
            {
                "id": metrics["id"],
                "name": metrics["name"],
                "bank_name": metrics["bank_name"],
                "iban": metrics["iban"],
                "currency": metrics["currency"],
                "opening_balance": str(
                    metrics["opening_balance"]
                ),
                "period_inflow": str(
                    metrics["period_inflow"]
                ),
                "period_outflow": str(
                    metrics["period_outflow"]
                ),
                "period_net": str(
                    metrics["period_net"]
                ),
                "closing_balance": str(
                    metrics["closing_balance"]
                ),
                "reconciliation_status": (
                    metrics["reconciliation_status"]
                ),
                "reconciliation_difference": (
                    metrics["reconciliation_difference"]
                ),
            }
            for metrics in account_metrics.values()
        ],
    }
