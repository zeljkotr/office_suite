import unittest
from decimal import Decimal

from app.services.financial_reports import (
    aggregate_signed_amounts,
    calculate_closing_balance,
    classify_payment_method,
)


class FinancialReportsTests(unittest.TestCase):
    def test_payment_method_classification(self):
        self.assertEqual(
            classify_payment_method("Cash"),
            "non_bank",
        )
        self.assertEqual(
            classify_payment_method("Bank transfer"),
            "bank",
        )
        self.assertEqual(
            classify_payment_method("SEPA transfer"),
            "bank",
        )
        self.assertEqual(
            classify_payment_method(None),
            "unclassified",
        )

    def test_aggregate_signed_amounts(self):
        result = aggregate_signed_amounts(
            [
                ("EUR", Decimal("100")),
                ("EUR", Decimal("-40")),
                ("EUR", Decimal("25")),
                ("RSD", Decimal("-1000")),
            ]
        )

        self.assertEqual(
            result["inflow"]["EUR"],
            "125",
        )
        self.assertEqual(
            result["outflow"]["EUR"],
            "40",
        )
        self.assertEqual(
            result["net"]["EUR"],
            "85",
        )
        self.assertEqual(
            result["outflow"]["RSD"],
            "1000",
        )

    def test_closing_balance(self):
        self.assertEqual(
            calculate_closing_balance("1000", "250"),
            Decimal("1250"),
        )

        self.assertEqual(
            calculate_closing_balance("1000", "-250"),
            Decimal("750"),
        )


if __name__ == "__main__":
    unittest.main()
